import os
import sys
import time
from xml.dom.minidom import parse

from pyspark import SparkConf, SparkContext

def hello():
    print("hello")

def parse_xml(xml_path):
    print("current path"+sys.path[0])
    doc = parse(xml_path)
    select_list = doc.getElementsByTagName('select')
    for select in select_list:
        name = select.getAttribute('name')
        print(name)

#py model_name model_arg1 model_arg2  model_argn
if __name__ == '__main__':
    hello()
    conf = SparkConf() \
        .setMaster("local[*]") \
        .setAppName("wordcount")
    sc = SparkContext.getOrCreate(conf)


    list = [1, 2, 3, 4, 5]
    rdd = sc.parallelize(list)
    print(rdd.collect())
    parse_xml('xml/spark.xml')
    print("current path" + sys.path[0])
    print("pid")
    print(os.getpid())
    time.sleep(100000)

