```
zip -r "sparrow-src" ./* -x "data/" -x ".git" -x ".pyc"
```

```
spark-submit --master local --py-files sparrow-src.zip --executor-memory 2G main.py
```

python main.py PYTHONPATH=