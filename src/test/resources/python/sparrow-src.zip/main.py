import os
import sys

import nnlog
from pyspark import SparkConf, SparkContext

# py model_name model_arg1 model_arg2  model_argn
from inner import hello, parse_xml

if __name__ == '__main__':
    log = nnlog.Logger('d://sparrow-python.log', level='info', backCount=5, when='D')  # 默认是debug级别最低的,默认保留5天的backCount when='D'

    # hello()
    conf = SparkConf() \
        .setMaster("local[*]") \
        .setAppName("wordcount")
    sc = SparkContext.getOrCreate(conf)

    list = [1, 2, 3, 4, 5]
    rdd = sc.parallelize(list)
    # print(rdd.collect())
    # parse_xml('xml/spark.xml')

    log.info("current path" + sys.path[0] + " pid " + str(os.getpid()))
    # time.sleep(100000)
