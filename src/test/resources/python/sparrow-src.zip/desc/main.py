import os
import sys
import time
from xml.dom.minidom import parse

from pyspark import SparkConf, SparkContext


#py model_name model_arg1 model_arg2  model_argn
from inner import hello, parse_xml

if __name__ == '__main__':
    hello()
    conf = SparkConf() \
        .setMaster("local[*]") \
        .setAppName("wordcount")
    sc = SparkContext.getOrCreate(conf)


    list = [1, 2, 3, 4, 5]
    rdd = sc.parallelize(list)
    print(rdd.collect())
    parse_xml('xml/spark.xml')
    print("current path" + sys.path[0])
    print("pid")
    print(os.getpid())
    time.sleep(100000)

