import sys
import os
print(sys.path[0])
